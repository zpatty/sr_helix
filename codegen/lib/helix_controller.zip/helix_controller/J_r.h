/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: J_r.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 23-Oct-2024 10:17:18
 */

#ifndef J_R_H
#define J_R_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void J_r(double q[10], double L0, double d, double Jr[30], double x_r[3]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for J_r.h
 *
 * [EOF]
 */
