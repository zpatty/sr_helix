/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_helix_controller_info.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 23-Oct-2024 10:17:18
 */

#ifndef _CODER_HELIX_CONTROLLER_INFO_H
#define _CODER_HELIX_CONTROLLER_INFO_H

/* Include Files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_helix_controller_info.h
 *
 * [EOF]
 */
