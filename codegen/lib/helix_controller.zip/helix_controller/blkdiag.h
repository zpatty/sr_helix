/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: blkdiag.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 23-Oct-2024 10:17:18
 */

#ifndef BLKDIAG_H
#define BLKDIAG_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void blkdiag(const double varargin_2[9], const double varargin_3[9],
             const double varargin_4[9], double y[100]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for blkdiag.h
 *
 * [EOF]
 */
