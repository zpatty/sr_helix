/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: helix_controller_types.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 23-Oct-2024 10:17:18
 */

#ifndef HELIX_CONTROLLER_TYPES_H
#define HELIX_CONTROLLER_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for helix_controller_types.h
 *
 * [EOF]
 */
